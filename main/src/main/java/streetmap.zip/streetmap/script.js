function initMap() {
    // Eerste kaart
    var map1 = L.map('map1').setView([51.505, -0.09], 13);
    
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
    }).addTo(map1);

    // Voeg een event listener toe voor het klikken op de kaart
    map1.on('click', function (event) {
        var lat = event.latlng.lat;
        var lng = event.latlng.lng;
        console.log('Hoogte coördinaat kaart 1: ' + lat + ', Breedte coördinaat kaart 1: ' + lng);
    });

    // Tweede kaart
    var map2 = L.map('map2').setView([51.505, -0.09], 13);

    // Gebruik de "NoLabels" tegel-laag voor de tweede kaart (geen namen)
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '© OpenStreetMap contributors'
    }).addTo(map2);

    // Voeg een event listener toe voor het klikken op de tweede kaart
    map2.on('click', function (event) {
        var lat = event.latlng.lat;
        var lng = event.latlng.lng;
        console.log('Hoogte coördinaat kaart 2: ' + lat + ', Breedte coördinaat kaart 2: ' + lng);
    });
}

window.onload = initMap;
 